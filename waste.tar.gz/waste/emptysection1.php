<section id="bottom">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="aligncenter">
          <h3><b style="color: black;border-bottom: 3px solid blue;">How We Work?</b></h3>
          <p>
            Do you want to get rid of your waste raddi and want to sell it in the best price then just give a missed call to us. <br/>
            We provide a free doorstep service that collects all your "Raddies" from the given address and pay instantly for it in fair prices by weighing it.

          </p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="span1"></div>
      <div class="span2">
        <div class="box aligncenter">
          <div class="aligncenter icon">
            <div class="img_block">
                <img src="img/make-call.jpg" class="data_img" >
            </div>
          </div>
          <div class="text">
            <strong>You Make us a Call</strong>
            <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->

          </div>
        </div>
      </div>
      <div class="span2">
        <div class="box aligncenter">
          <div class="aligncenter icon">
            <div class="img_block">
              <img src="img/customer-location.jpg" class="data_img" >
            </div>
          </div>
          <div class="text">
            <strong>You tell us Location</strong>
            <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->

          </div>
        </div>
      </div>
      <div class="span2">
        <div class="box aligncenter">
          <div class="aligncenter icon">
            <div class="img_block">
              <img src="img/at-door.jpg" class="data_img" >
            </div>
          </div>
          <div class="text">
          <strong>We Reach To your door step.</strong>
            <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->
          </div>
        </div>
      </div>
      <div class="span2">
        <div class="box aligncenter">
          <div class="aligncenter icon">
            <div class="img_block">
              <img src="img/picked-items.jpg" class="data_img" >
            </div>
          </div>
          <div class="text">
          <strong>We Pick your scaps and pay for it.</strong>
            <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->
          </div>
        </div>
      </div>
      <div class="span2">
        <div class="box aligncenter">
          <div class="aligncenter icon">
            <div class="img_block">
              <img src="img/customer-glad.jpg" class="data_img" >
            </div>
          </div>
          <div class="text">
              <strong>You will Glad</strong>
            <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->
          </div>
        </div>
      </div>
        <div class="span1"></div>
    </div>
  </div>
</section>
