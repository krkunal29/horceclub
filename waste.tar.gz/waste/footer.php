<div class="contact" id="contact">
    <div class="container">
        <div class="row">
          <div class="span12">
            <div class="box aligncenter">
                <h2  data-aos="fade-up" data-aos-duration="1000">
                    Let's Get In Touch!</h2>
                <hr class="primary">
                <p data-aos="fade-up" data-aos-duration="1000">
                    Give us a call or send us an email and we will get back to you as soon as possible!</p>
            </div>

          
            </div>
        </div>
        <div class="row">
          <div class="span2">

          </div>
          <div class="span4">
            <div class="box aligncenter">
              <div class="aligncenter icon">
                <div class="img_block">
                    <img src="img/what1.png" style="height: 40px;">
                </div>
              </div>
              <div class="text">
                <strong>  <p class="contact-dt">
                      <a href="https://web.whatsapp.com/+91-7745876718">
                        +91-7745876718</a></p>
                      </strong>
                <p>Vedant Kapse</p>

              </div>
            </div>
          </div>
          <div class="span4">
            <div class="box aligncenter">
              <div class="aligncenter icon">
                <div class="img_block">
                    <img src="img/what1.png" style="height: 40px;" >
                </div>
              </div>
              <div class="text">
                <strong><p class="contact-dt">
                      <a href="https://web.whatsapp.com/+91-9665239845">
                        +91-9665239845</a></p>
                  </strong>
                  <p>Vedant Kapse</p>

              </div>
            </div>
          </div>
          <div class="span2">

          </div>

        </div>

    </div>
</div>
