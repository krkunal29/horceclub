<div id="sub-footer">
  <div class="container">
    <div class="row">
      <div class="span6">
        <div class="copyright">
          <p>
            <span>&copy;Kunal Kapse - All right reserved.</span>
          </p>
          <div class="credits">
            Designed by <a href="#">Kunal Kapse</a>
            <!-- Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> -->
          </div>
        </div>
      </div>
      <div class="span6">
        <ul class="social-network">
          <li><a href="#" data-placement="bottom" title="Facebook"><i class="icon-facebook icon-square"></i></a></li>
          <li><a href="#" data-placement="bottom" title="Twitter"><i class="icon-twitter icon-square"></i></a></li>
          <li><a href="#" data-placement="bottom" title="Linkedin"><i class="icon-linkedin icon-square"></i></a></li>
          <li><a href="#" data-placement="bottom" title="Pinterest"><i class="icon-pinterest icon-square"></i></a></li>
          <li><a href="#" data-placement="bottom" title="Google plus"><i class="icon-google-plus icon-square"></i></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
