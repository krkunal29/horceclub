<div class="hidden-top">
  <div class="hidden-top-inner container">
    <div class="row">
      <div class="span12">
        <ul>
          <!-- <li><strong>We are available for your service</strong></li> -->
          <li>Main office: Flat No 4 Mangalmurti Apartment Pharadi phata Nashik</li>
          <li> <i class="icon-phone"></i> +91-7745876718</li>
          <li> <i class="icon-phone"></i> +91-9665239845</li>
          <li><i class="icon-phone"></i> +91-7276313931</li>

        </ul>
      </div>
    </div>
  </div>
</div>
