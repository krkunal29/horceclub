<section class="callaction">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="big-cta">
          <div class="cta-text">
            <h3><span class="highlight"><strong>REDUCE </strong><strong>REUSE </strong><strong>RECYCLE</strong><strong> REPEAT</strong></span></h3>
          </div>
          <div class="cta floatright">
            <a class="btn btn-large btn-theme btn-rounded" href="#">Request a quote</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
