<section id="bottom">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="aligncenter">
          <h3><b style="color: black;border-bottom: 3px solid blue;">Why Raddi Mail?</b></h3>
          <p>
            We offers door to door free pick up service for your scraps.</br>
            While dealing with local raddi wala, you have to go through lots of bargaining.</br> Even there is no assurance of fair measurements on his ordinary Taraju.</br>
            At Raddi Bazar, we use standard, government certified weighing machine and also give you authentic bill of transaction.
          </p>
        </div>
      </div>
    </div>
  </div>
</section>
