<section id="content" style="background-color: cornflowerblue;">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="aligncenter">
          <h3><b style="color: white;">What We Collect?</b></h3>

        </div>
      </div>
    </div>
<div class="row">
  <div class="span4">
    <div class="box aligncenter">
      <div class="aligncenter icon">
        <div class="img_block">
            <img src="img/e-waste.png" class="data_img" alt="E- Waste">
        </div>
      </div>
      <div class="text">
        <h3>E- Waste</h3>
        <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->

      </div>
    </div>
  </div>
  <div class="span4">
    <div class="box aligncenter">
      <div class="aligncenter icon">
        <div class="img_block">
          <img src="img/plastic.png" class="data_img" alt="Plastic">
        </div>
      </div>
      <div class="text">
        <h3>Plastic</h3>
        <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->

      </div>
    </div>
  </div>
  <div class="span4">
    <div class="box aligncenter">
      <div class="aligncenter icon">
        <div class="img_block">
          <img src="img/metal.png" class="data_img" alt="Metal">
        </div>
      </div>
      <div class="text">
        <h3>Metal</h3>
        <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->
      </div>
    </div>
  </div>

</div>
<div class="row">
  <div class="span4">
    <div class="box aligncenter">
      <div class="aligncenter icon">
        <div class="img_block">
            <img src="img/paper.png" class="data_img" alt="Paper">
        </div>
      </div>
      <div class="text">
        <h3>Paper</h3>
        <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->
      </div>
    </div>
  </div>
  <div class="span4">
    <div class="box aligncenter">
      <div class="aligncenter icon">
        <div class="img_block">
          <img src="img/glass.png" class="data_img" alt="Glasses">
        </div>
      </div>
      <div class="text">
        <h3>Glasses</h3>
        <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->
      </div>
    </div>
  </div>
  <div class="span4">
    <div class="box aligncenter">
      <div class="aligncenter icon">
        <div class="img_block">
              <img src="img/hazardous.png" class="data_img" alt="Hazardous">
        </div>
      </div>
      <div class="text">
        <h3>Hazardous</h3>
        <!-- <p><i class="fa fa-rupee"></i><span>7.00 / kg</span> </p> -->
      </div>
    </div>
  </div>
</div>

</div>
</section>
