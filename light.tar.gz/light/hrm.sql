-- phpMyAdmin SQL Dump
-- version 4.7.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 22, 2019 at 10:38 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hrm`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(12) NOT NULL,
  `uid` int(12) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirmpassword` varchar(50) NOT NULL,
  `clientid` varchar(20) NOT NULL,
  `phoneno` varchar(15) NOT NULL,
  `companyname` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `uid`, `firstname`, `lastname`, `username`, `email`, `password`, `confirmpassword`, `clientid`, `phoneno`, `companyname`, `created_at`, `updated_at`) VALUES
(2, 4, 'kunal', 'kapse', 'kunal29', 'kunal29@gmail.com', 'kk', 'kk', 'CLI-1', '7588622005', 'TCS Company pvt', '2018-06-22 17:45:26', '2018-06-22 17:45:26'),
(3, 4, 'kunal', 'kapse', 'kunal', 'krkunal29@gamail.com', 'kk', 'kk', 'CLI-2', '7485962312', 'xxovek', '2018-09-02 09:44:54', '2018-09-02 09:44:54');

-- --------------------------------------------------------

--
-- Table structure for table `companyprofile`
--

CREATE TABLE `companyprofile` (
  `id` int(12) NOT NULL,
  `uid` int(12) NOT NULL,
  `companyname` varchar(20) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `city` varchar(10) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `postalcode` varchar(10) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `phoneno` varchar(20) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `websiteurl` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companyprofile`
--

INSERT INTO `companyprofile` (`id`, `uid`, `companyname`, `contactno`, `address`, `country`, `city`, `state`, `postalcode`, `email`, `phoneno`, `mobileno`, `fax`, `websiteurl`, `created_at`, `updated_at`) VALUES
(2, 4, 'Talent Search', 'Vikas Pawar', '121 Gandhi nagar , parola Road , Dhule', 'INDIA', 'Dhule', 'Gujrat', '85967', 'vikas@gmail.com', '7588521102', '75886222005', 'www.fax.com', 'www.url.com', '2018-06-20 19:00:58', '2018-06-20 19:00:58');

-- --------------------------------------------------------

--
-- Table structure for table `createproject`
--

CREATE TABLE `createproject` (
  `id` int(12) NOT NULL,
  `uid` int(12) NOT NULL,
  `projectname` varchar(100) NOT NULL,
  `clientcompany` varchar(100) NOT NULL,
  `startdate` varchar(10) NOT NULL,
  `enddate` varchar(10) NOT NULL,
  `rate` varchar(20) NOT NULL,
  `rateinhours` varchar(20) NOT NULL,
  `priority` varchar(10) NOT NULL,
  `addprojectleader` varchar(100) NOT NULL,
  `addteam` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `createproject`
--

INSERT INTO `createproject` (`id`, `uid`, `projectname`, `clientcompany`, `startdate`, `enddate`, `rate`, `rateinhours`, `priority`, `addprojectleader`, `addteam`, `description`, `created_at`, `updated_at`) VALUES
(3, 4, 'HRMS', 'TCS Company pvt', '23/06/2018', '29/06/2018', '500', 'Hourly', 'High', 'Arnav Singh', 'Premraj', '<p>This best team deginer.<br></p>', '2018-06-23 06:25:38', '2018-06-23 06:25:38'),
(4, 4, 'HRMS', 'TCS Company pvt', '23/06/2018', '29/06/2018', '500', 'Fixed', 'High', 'Arnav Singh', 'Premraj', '<p>This best team deginer.<br></p>', '2018-06-23 06:26:16', '2018-06-23 06:26:16'),
(5, 4, 'RaJ Construction', 'TCS Company pvt', '21/06/2018', '29/06/2018', '', 'Fixed', 'High', 'Bhushan', 'Rahul Dravid', '', '2018-06-23 06:27:08', '2018-06-23 06:27:08'),
(6, 4, 'Billing Software ERP', 'TCS Company pvt', '23/08/2018', '25/08/2018', '500 rs', 'Fixed', 'Medium', 'Arnav Singh', 'Rahul Chudhari', '<p>HELLO<br></p>', '2018-08-22 17:33:17', '2018-08-22 17:33:17'),
(7, 4, '', '', '', '', '', 'Hourly', 'High', '', '', '', '2018-09-02 09:50:23', '2018-09-02 09:50:23'),
(8, 4, 'kunal', 'TCS Company pvt', '13/09/2018', '13/09/2018', '52', 'Hourly', 'Medium', 'dd', 'dd', '<p>dd<br></p>', '2018-09-02 09:50:50', '2018-09-02 09:50:50');

-- --------------------------------------------------------

--
-- Table structure for table `Employyes`
--

CREATE TABLE `Employyes` (
  `Emp_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `useremail` varchar(50) DEFAULT NULL,
  `userpassword` varchar(20) DEFAULT NULL,
  `Joiningdate` varchar(20) DEFAULT NULL,
  `userphone` varchar(20) DEFAULT NULL,
  `company` varchar(50) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Employyes`
--

INSERT INTO `Employyes` (`Emp_id`, `uid`, `firstname`, `lastname`, `username`, `useremail`, `userpassword`, `Joiningdate`, `userphone`, `company`, `designation`, `created_at`, `updated_at`) VALUES
(38, 4, 'vikas', 'pawar', 'vikas1', 'vikas@gmail.com', 'vikas1', '15/06/2018', '9766695099', 'Global Technologies', 'SEO Analyst', '2018-06-20 18:58:33', '2018-06-20 18:58:33'),
(39, 4, 'Rutuj', 'Shinde', 'rj1534', 'rj@gmail.com', 'rj', '27/06/2018', '7588622251', 'Delta Infotech', 'Web Designer', '2018-06-20 19:13:39', '2018-06-20 19:13:39');

-- --------------------------------------------------------

--
-- Table structure for table `usereducationinformation`
--

CREATE TABLE `usereducationinformation` (
  `id` int(10) NOT NULL,
  `uid` int(12) NOT NULL,
  `empid` int(12) NOT NULL,
  `institution` varchar(100) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `startingdate` varchar(20) DEFAULT NULL,
  `completedate` varchar(20) DEFAULT NULL,
  `degree` varchar(20) DEFAULT NULL,
  `grade` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usereducationinformation`
--

INSERT INTO `usereducationinformation` (`id`, `uid`, `empid`, `institution`, `subject`, `startingdate`, `completedate`, `degree`, `grade`, `created_at`) VALUES
(4, 4, 4, 'Pune university ', 'Computer science', '29/12/1993', '29/12/1995', 'Msc Computer science', 'A+', '2018-06-20 18:42:27'),
(5, 4, 38, 'IIT Pune', 'cs', '14/12/2015', '25/01/2015', 'Msc Computer Science', 'A+', '2018-06-20 19:26:31'),
(6, 4, 39, 'CBI Institute', 'Narcotics Officer', '20-10-15', '20-10-15', 'B-TECH', 'A+', '2018-06-21 01:56:15'),
(7, 4, 39, 'MIT PUNE WPU', 'ANTI-DRUG Resercher', '20-1-16', '20-1-17', 'Msc computer', 'A+', '2018-06-21 01:57:29');

-- --------------------------------------------------------

--
-- Table structure for table `userexperienceinformation`
--

CREATE TABLE `userexperienceinformation` (
  `id` int(12) NOT NULL,
  `uid` int(12) NOT NULL,
  `empid` int(12) NOT NULL,
  `companyname` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `jobposition` varchar(50) NOT NULL,
  `periodfrom` varchar(50) NOT NULL,
  `periodto` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userexperienceinformation`
--

INSERT INTO `userexperienceinformation` (`id`, `uid`, `empid`, `companyname`, `location`, `jobposition`, `periodfrom`, `periodto`, `created_at`) VALUES
(2, 4, 4, 'Xxovek company pvt ltd', 'Pune University', 'Software delvoper', '12/2/2015', '12/5/2017', '2018-06-20 18:44:24'),
(3, 4, 38, 'Wipro Colony ', 'near pune university', 'Senior Software Delveoper', '25/12/2015', '12/12/2017', '2018-06-20 19:27:40'),
(4, 4, 39, 'INFO TEXH', 'Pune City', '20-12-2017`', '20-12-2017', '2019', '2018-06-21 02:10:55');

-- --------------------------------------------------------

--
-- Table structure for table `userpayslip`
--

CREATE TABLE `userpayslip` (
  `id` int(12) NOT NULL,
  `uid` int(12) NOT NULL,
  `empid` int(12) NOT NULL,
  `selectstaff` varchar(20) DEFAULT NULL,
  `netsalary` varchar(10) DEFAULT NULL,
  `basic` varchar(10) DEFAULT NULL,
  `da` varchar(10) DEFAULT NULL,
  `hra` varchar(10) DEFAULT NULL,
  `conveyance` varchar(10) DEFAULT NULL,
  `allowance` varchar(10) DEFAULT NULL,
  `medicalallowance` varchar(10) DEFAULT NULL,
  `others` varchar(10) DEFAULT NULL,
  `tds` varchar(10) DEFAULT NULL,
  `esi` varchar(10) DEFAULT NULL,
  `pf` varchar(10) DEFAULT NULL,
  `leave1` varchar(10) DEFAULT NULL,
  `proftax` varchar(10) DEFAULT NULL,
  `labwelfare` varchar(10) DEFAULT NULL,
  `fund` varchar(10) DEFAULT NULL,
  `otherdeducation` varchar(10) DEFAULT NULL,
  `total` int(12) NOT NULL,
  `empemail` varchar(50) NOT NULL,
  `empjoindate` varchar(50) NOT NULL,
  `empdesignation` varchar(100) NOT NULL,
  `emprole` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userpayslip`
--

INSERT INTO `userpayslip` (`id`, `uid`, `empid`, `selectstaff`, `netsalary`, `basic`, `da`, `hra`, `conveyance`, `allowance`, `medicalallowance`, `others`, `tds`, `esi`, `pf`, `leave1`, `proftax`, `labwelfare`, `fund`, `otherdeducation`, `total`, `empemail`, `empjoindate`, `empdesignation`, `emprole`, `created_at`, `updated_at`) VALUES
(1, 2, 6, 'kunal kapse', '15000', '1500', '100', '10', '1', '55', '55', '55', '10', '55', '55', '55', '55', '55', '55', '55', 16381, 'vbpawar@gmail.com', '17/06/2018', 'SEO', 'Delta', '2018-06-17 14:19:33', '2018-06-17 14:19:33'),
(2, 2, 2, 'vikas pawar', '15000', '1500', '10', '1', '10', '11', '1', '11', '120', '12', '12', '11', '12', '12', '1', '12', 16352, 'vbpawar@gmail.com', '02/06/2018', 'SEO Analyst', 'Delta Infotech', '2018-06-17 18:27:44', '2018-06-17 18:27:44'),
(3, 4, 38, 'vikas pawar', '15000', '1000', '100', '20', '20', '10', '20', '30', '30', '30', '3', '10', '10', '20', '20', '2', 16075, 'vikas@gmail.com', '15/06/2018', 'SEO Analyst', 'Global Technologies', '2018-06-21 01:49:31', '2018-06-21 01:49:31'),
(4, 4, 39, 'Rutuj Shinde', '1000', '10', '50', '40', '10', '10', '10', '12', '10', '10', '10', '15', '10', '10', '10', '15', 1052, 'rj@gmail.com', '27/06/2018', 'Web Designer', 'Delta Infotech', '2018-06-21 01:53:55', '2018-06-21 01:53:55');

-- --------------------------------------------------------

--
-- Table structure for table `userprofile`
--

CREATE TABLE `userprofile` (
  `id` int(10) NOT NULL,
  `empid` int(12) NOT NULL,
  `uid` int(10) NOT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `birthdate` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(20) NOT NULL,
  `state` varchar(20) DEFAULT NULL,
  `pincode` varchar(10) NOT NULL,
  `contactno` varchar(20) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userprofile`
--

INSERT INTO `userprofile` (`id`, `empid`, `uid`, `firstname`, `lastname`, `birthdate`, `gender`, `address`, `country`, `state`, `pincode`, `contactno`, `create_at`, `updated_at`) VALUES
(3, 4, 4, 'kunal', 'kapse', '29/06/2018', 'Male', '121 gandhi nagar parola road dhule', 'india', 'maharashtra', '424001', '9766695099', '2018-06-20 18:44:31', '2018-06-20 18:44:31'),
(4, 38, 4, 'vikas', 'pawar', '22/06/2018', 'Male', '121 gokul colony Rahuri Pune 424001', 'India', 'Maharashtra', '420024', '9766695099', '2018-06-20 19:27:58', '2018-06-20 19:27:58'),
(5, 39, 4, 'ARNAV SINGH', 'RAYZADA', '14/06/2018', 'Male', '121 Gandhi nagar dhule', 'india', 'maharashtra', '424001', '9766695099', '2018-06-20 19:42:51', '2018-06-21 01:57:46');

-- --------------------------------------------------------

--
-- Table structure for table `userregistration`
--

CREATE TABLE `userregistration` (
  `id` int(10) NOT NULL,
  `uname` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userregistration`
--

INSERT INTO `userregistration` (`id`, `uname`, `email`, `password`, `contactno`) VALUES
(4, 'kunal', 'kk@gmail.com', 'kk', '9766695099');

-- --------------------------------------------------------

--
-- Table structure for table `userskill`
--

CREATE TABLE `userskill` (
  `id` int(11) NOT NULL,
  `uid` int(12) NOT NULL,
  `empid` int(12) NOT NULL,
  `skill` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userskill`
--

INSERT INTO `userskill` (`id`, `uid`, `empid`, `skill`, `created_at`) VALUES
(10, 4, 4, 'CS', '2018-06-20 18:42:39'),
(11, 4, 4, 'HTML', '2018-06-20 18:42:48'),
(12, 4, 4, 'VB.NET', '2018-06-20 18:42:54'),
(13, 4, 4, 'JS', '2018-06-20 18:43:01'),
(14, 4, 4, 'Javascript', '2018-06-20 18:43:08'),
(15, 4, 4, 'TypeScript', '2018-06-20 18:43:19'),
(16, 4, 38, 'Andoird', '2018-06-20 19:27:49'),
(17, 4, 38, 'PHP', '2018-06-20 19:27:55'),
(18, 4, 38, 'HTML', '2018-06-20 19:28:51'),
(19, 4, 39, 'HTML', '2018-06-21 01:57:43'),
(20, 4, 38, 'PHP 5.0', '2019-05-22 07:28:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companyprofile`
--
ALTER TABLE `companyprofile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `createproject`
--
ALTER TABLE `createproject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Employyes`
--
ALTER TABLE `Employyes`
  ADD PRIMARY KEY (`Emp_id`);

--
-- Indexes for table `usereducationinformation`
--
ALTER TABLE `usereducationinformation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userexperienceinformation`
--
ALTER TABLE `userexperienceinformation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userpayslip`
--
ALTER TABLE `userpayslip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userprofile`
--
ALTER TABLE `userprofile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userregistration`
--
ALTER TABLE `userregistration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userskill`
--
ALTER TABLE `userskill`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `companyprofile`
--
ALTER TABLE `companyprofile`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `createproject`
--
ALTER TABLE `createproject`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `Employyes`
--
ALTER TABLE `Employyes`
  MODIFY `Emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `usereducationinformation`
--
ALTER TABLE `usereducationinformation`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `userexperienceinformation`
--
ALTER TABLE `userexperienceinformation`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `userpayslip`
--
ALTER TABLE `userpayslip`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `userprofile`
--
ALTER TABLE `userprofile`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `userregistration`
--
ALTER TABLE `userregistration`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `userskill`
--
ALTER TABLE `userskill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
