<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'HRM';

$con = new mysqli($servername,$username,$password,$database) or die(mysqli_error());
?>
